from Brain_games.games.progression_game import progression


def main():
    progression()


if __name__ == '__main__':
    main()
