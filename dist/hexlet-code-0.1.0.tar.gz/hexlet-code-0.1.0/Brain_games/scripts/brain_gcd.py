from Brain_games.games.gcd_game import game_of_gcd


def main():
    game_of_gcd()


if __name__ == '__main__':
    main()
