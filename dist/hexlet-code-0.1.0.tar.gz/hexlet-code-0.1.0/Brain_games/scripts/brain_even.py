from Brain_games.games.even_game import game_of_even


def main():
    game_of_even()


if __name__ == '__main__':
    main()
