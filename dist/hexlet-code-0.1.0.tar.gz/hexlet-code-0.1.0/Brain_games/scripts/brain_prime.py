from Brain_games.games.prime_game import game_of_prime


def main():
    game_of_prime()


if __name__ == '__main__':
    main()
